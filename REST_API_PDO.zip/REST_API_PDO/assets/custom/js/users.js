    //////////////////////////////////////////////////////////////////////////
    /////                                                              /////// 
    /////                  Web Developer : Junil toledo                ///////
    /////                                                             ///////
    /////////////////////////////////////////////////////////////////////////


    $(document).ready(function() {

              let api = "http://localhost/REST_API_PDO/users";

                  ///////////////////////////////////add//////////////////////////////////////

               $(document).delegate('#btn-user', 'click', function(event) {
                     event.preventDefault();
                  
                      var name = $('#name').val();
                      var email = $('#email').val();
                      var phone = $('#phone').val();
 
                        if(name == "" || email == "" || phone == "") {
                          $('#req_u').html("<div class='alert alert-danger'>All fields are required</div>");
                          return;
                        }
                        $.ajax({
                            url: api, 
                            type : "POST",
                            dataType : 'json',
                            data: {name: name, email: email, phone: phone},
                            success : function(result) {
                                    $('#msg-user').html('<div class="alert alert-success">User added successfully</div>');
                                      setTimeout(function () {  
                                           location.reload(true);
                                         }, 1000);
                            },
                            error: function(xhr, resp, text) {
                                console.log(xhr, resp, text);
                            }
                        })
                    });
          

          ////////////////////////////////////end add/////////////////////////////////

          //////////////////////////////////////fetch data////////////////////////////

               $.ajax({
                      url: api, 
                      type : "GET",
                      dataType : 'json',
                        success : function(json2) {
                        var tr=[];
                              for (var i = 0; i < json2.length; i++) {
                                tr.push('<tr>');
                                tr.push('<td>' + json2[i].id + '</td>');
                                tr.push('<td>' + json2[i].name + '</td>');
                                tr.push('<td>' + json2[i].email + '</td>');
                                tr.push('<td>' + json2[i].phone + '</td>');
                                tr.push('<td>' + json2[i].date_created + '</td>');
                                tr.push('<td><button class=\'btn btn-outline-primary btn_edit\' data-toggle=\'modal\' data-target=\'#edit_modal\' data-edit=' + json2[i].id  + '>Edit</button>&nbsp;&nbsp;<button class=\'btn btn-outline-danger btn_delete\' data-toggle=\'modal\' data-target=\'#delete_modal\' data-dlet=' + json2[i].id  + '>Delete</button></td>');
                                tr.push('</tr>');
                              }
                              $('#users_table').append($(tr.join('')));
                         } 

                  });
       
              ///////////////////////////////////end fetch data///////////////////////////////


              //////////////////////////////////edit get Id ////////////////////////////////////////

             $(document).on("click", ".btn_edit", function() {

                     var id = $(this).data("edit");
                     getID(id);//argument
                     function getID(id) {
                        $.ajax({
                            type: 'GET',
                            url: api+"/"+id,
                            dataType: 'json',
                            success: function(response) {
                              for (var i = 0; i < response.length; i++) {
                                $('#edit_id').val(response[i].id);
                                $('#edit_name').val(response[i].name);
                                $('#edit_email').val(response[i].email);
                                $('#edit_phone').val(response[i].phone);
                           }
                         }
                      });
                    }

                });


              //////////////////////////////////////////end edit get Id/////////////////////////////

                ///////////////////////////////////////update process////////////////////////////////


                  $(document).delegate('#btn-edituser', 'click', function(event) {
                    event.preventDefault();
                     
                     var name = $('#edit_name').val();
                     var email = $('#edit_email').val();
                     var phone = $('#edit_phone').val();
                     var id = $('#edit_id').val();

                    $.ajax({
                      type: "PUT",
                      dataType: 'json',
                      url: api+"/"+id,
                      data: {name: name, email: email, phone: phone},
                      cache: false,
                      success: function(result) {
                        $('#mgs_uedit').html('<div class="alert alert-success">User Updated successfully</div>');
                          setTimeout(function () {  
                               location.reload(true);
                             }, 1000);
                              
                      },
                      error: function(err) {
                        alert(err);
                      }
                    });
                  });
              

              ///////////////////////////////////////update process////////////////////////////////

            //////////////////////////////////edit get Id delete ////////////////////////////////////////

             $(document).on("click", ".btn_delete", function() {
                  var id = $(this).data("dlet");
                  getdelID(id);//argument

                   function getdelID(id) {
                      $.ajax({
                          type: 'GET',
                          url: api+"/"+id,
                          dataType: 'json',
                          success: function(response2) {
                             for (var i = 0; i < response2.length; i++) {
                                $('#del_id').val(response2[i].id);
                                $('#del_name').val(response2[i].name);
                           }
      
                       }
                    });
                   }

                });

              //////////////////////////////////////////end edit get Id delete///////////////////////////////

               ////////////////////////////////// delete process////////////////////////////////////////

               $(document).delegate('#btn-deltuser', 'click', function(event) {
                    event.preventDefault();

                   var id = $('#del_id').val();

                    $.ajax({
                      type: "DELETE",
                      url: api+"/"+id,
                      cache: false,
                      success: function(result) {
                        $('#mgs_udel').html('<div class="alert alert-success">User Deleted successfully</div>');
                          setTimeout(function () {  
                               location.reload(true);
                             }, 1000);
                              
                      },
                      error: function(err) {
                        alert(err);
                      }
                    });
                  });
              
             
              //////////////////////////////////////////end delete process///////////////////////////////

      });