<!-- Modal add-->
<div class="modal fade" id="user_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" id="form">
            <div id="req_u"></div>
            <div id="msg-user"></div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                </div>
             <div class="col-12">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                </div>
                 <div class="col-12">
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="number" class="form-control" id="phone" name="phone">
                    </div>
                </div>
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" name="submit" id="btn-user">Save</button>
      </div>
    </div>
  </div>
</div>

<!--end Modal add-->

<!-- Modal edit-->
<div class="modal fade" id="edit_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" id="form">
            <div id="mgs_uedit"></div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" id="edit_name" name="name">
                    </div>
                </div>
             <div class="col-12">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email">
                    </div>
                </div>
                 <div class="col-12">
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="number" class="form-control" id="edit_phone" name="phone">
                    </div>
                </div>
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="edit_id" name="">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" name="submit" id="btn-edituser">Update</button>
      </div>
    </div>
  </div>
</div>

<!--end Modal edit-->

<!-- Modal delete-->
<div class="modal fade" id="delete_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" id="form">
            <div id="mgs_udel"></div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" id="del_name" name="name">
                    </div>
                </div>
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <input type="hidden" id="del_id" name="">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <button type="button" class="btn btn-primary" name="submit" id="btn-deltuser">Yes</button>
      </div>
    </div>
  </div>
</div>

<!--end Modal delete-->